# Programs

![Commit](https://github.com/adityaa30/programs/workflows/Check%20Commit/badge.svg)
![Test](https://github.com/adityaa30/programs/workflows/Test/badge.svg)
