DIR_NAME=Compete

mkdir -p $DIR_NAME

cp $1 $DIR_NAME/A.cpp
cp $1 $DIR_NAME/B.cpp
cp $1 $DIR_NAME/C.cpp
cp $1 $DIR_NAME/D.cpp
cp $1 $DIR_NAME/E.cpp
cp $1 $DIR_NAME/F.cpp

